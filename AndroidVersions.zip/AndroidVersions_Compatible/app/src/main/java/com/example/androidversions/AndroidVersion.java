package com.example.androidversions;

public class AndroidVersion {
    private final int imageResId;
    private final String codeName;
    private final String version;

    public AndroidVersion(int imageResId, String codeName, String version) {
        this.imageResId = imageResId;
        this.codeName = codeName;
        this.version = version;
    }

    public int getImageResId() {
        return imageResId;
    }

    public String getCodeName() {
        return codeName;
    }

    public String getVersion() {
        return version;
    }
}
