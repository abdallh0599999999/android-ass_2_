package com.example.androidversions;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AndroidVersionAdapter extends RecyclerView.Adapter<AndroidVersionAdapter.VersionViewHolder> {
    private final List<AndroidVersion> androidVersions;

    public AndroidVersionAdapter(List<AndroidVersion> androidVersions) {
        this.androidVersions = androidVersions;
    }

    @NonNull
    @Override
    public VersionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_android_version, parent, false);
        return new VersionViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull VersionViewHolder holder, int position) {
        AndroidVersion currentVersion = androidVersions.get(position);
        holder.versionLogo.setImageResource(currentVersion.getImageResId());
        holder.codeNameText.setText(currentVersion.getCodeName());
        holder.versionText.setText(currentVersion.getVersion());

        int color = position % 2 == 0 ? R.color.row_even : R.color.row_odd;
        holder.itemContainer.setBackgroundColor(
                ContextCompat.getColor(holder.itemView.getContext(), color));

        holder.itemView.setOnClickListener(v -> Toast.makeText(
                v.getContext(),
                "You selected: " + currentVersion.getCodeName() + " (" + currentVersion.getVersion() + ")",
                Toast.LENGTH_SHORT).show());
    }

    @Override
    public int getItemCount() {
        return androidVersions.size();
    }

    static class VersionViewHolder extends RecyclerView.ViewHolder {
        ImageView versionLogo;
        TextView codeNameText;
        TextView versionText;
        ConstraintLayout itemContainer;

        VersionViewHolder(@NonNull View itemView) {
            super(itemView);
            versionLogo = itemView.findViewById(R.id.versionLogo);
            codeNameText = itemView.findViewById(R.id.codeNameText);
            versionText = itemView.findViewById(R.id.versionText);
            itemContainer = itemView.findViewById(R.id.itemContainer);
        }
    }
}
