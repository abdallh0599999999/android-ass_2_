package com.example.androidversions;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {
    private final ArrayList<AndroidVersion> androidVersionList = new ArrayList<>();
    private AndroidVersionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        Button sortButton = findViewById(R.id.sortButton);

        createAndroidVersionsList();

        adapter = new AndroidVersionAdapter(androidVersionList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);

        sortButton.setOnClickListener(v -> {
            Collections.sort(androidVersionList, Comparator.comparing(AndroidVersion::getCodeName));
            adapter.notifyDataSetChanged();
        });
    }

    private void createAndroidVersionsList() {
        androidVersionList.add(new AndroidVersion(R.drawable.donut, "Donut", "1.6"));
        androidVersionList.add(new AndroidVersion(R.drawable.eclair, "Éclair", "2.0 - 2.1"));
        androidVersionList.add(new AndroidVersion(R.drawable.froyo, "Froyo", "2.2 - 2.2.3"));
        androidVersionList.add(new AndroidVersion(R.drawable.gingerbread, "Gingerbread", "2.3 - 2.3.7"));
        androidVersionList.add(new AndroidVersion(R.drawable.honeycomb, "Honeycomb", "3.0 - 3.2.6"));
        androidVersionList.add(new AndroidVersion(R.drawable.icecream, "Ice Cream Sandwich", "4.0 - 4.0.4"));
        androidVersionList.add(new AndroidVersion(R.drawable.jellybean, "Jelly Bean", "4.1 - 4.3.1"));
        androidVersionList.add(new AndroidVersion(R.drawable.kitkat, "KitKat", "4.4 - 4.4.4"));
        androidVersionList.add(new AndroidVersion(R.drawable.lollipop, "Lollipop", "5.0 - 5.1.1"));
        androidVersionList.add(new AndroidVersion(R.drawable.marshmallow, "Marshmallow", "6.0 - 6.0.1"));
        androidVersionList.add(new AndroidVersion(R.drawable.nougat, "Nougat", "7.0 - 7.1.2"));
        androidVersionList.add(new AndroidVersion(R.drawable.oreo, "Oreo", "8.0 - 8.1"));
    }
}
